package mooc.vandy.java4android.gate.logic;

import java.util.Random;

import mooc.vandy.java4android.gate.ui.OutputInterface;

/**
 * This class uses your Gate class to manage a herd of snails.  We
 * have supplied you will the code necessary to execute as an app.
 * You must fill in the missing logic below.
 */
public class HerdManager {
    /**
     * Reference to the output.
     */
    private OutputInterface mOut;

    /**
     * The input Gate object.
     */
    private Gate mEastGate;

    /**
     * The output Gate object.
     */
    private Gate mWestGate;

    /**
     * Maximum number of iterations to run the simulation.
     */
    private static final int MAX_ITERATIONS = 10;

    /**
    * Size of the HERD
    */
    public static final int HERD = 24;

    /**
     * Constructor initializes the fields.
     */
    public HerdManager(OutputInterface out,
                       Gate westGate,
                       Gate eastGate) {
        mOut = out;

        mWestGate = westGate;
        mWestGate.open(Gate.IN);

        mEastGate = eastGate;
        mEastGate.open(Gate.OUT);
    }

    // TODO -- Fill your code in here
    public void simulateHerd (Random rand) {
        int herd = 24;
        int pasture = 0;    // No of snails in the pasture
        mOut.println("There are " + herd + " snails in the pen and " + pasture +
                " snails in the pasture");
        Gate gate = null;
        for (int i = 0; i < MAX_ITERATIONS; i++) {
            gate = selectGate(rand);
            if ((gate == mEastGate && herd > 0 && pasture < 24) || (pasture == 0)) {
                herd += gate.thru(rand.nextInt(herd) + 1);

            }
            else if ((gate == mWestGate && pasture > 0 && herd < 24) || (herd == 0)) {
                herd += gate.thru(rand.nextInt(pasture) + 1);
            }
            pasture = 24 - herd;
            mOut.println("There are " + herd + " snails in the pen and " + pasture +
                    " snails in the pasture");
        }
    }

    private Gate selectGate(Random rand) {
        if (rand.nextInt(2) == 0) { return mWestGate; }
        return mEastGate;
    }
}
