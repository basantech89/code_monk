package mooc.vandy.java4android.gate.logic;

/**
 * Enum to indicate which class to test.
 */
public enum ClassToTest {
    /**
     * Test the FillTheCorral class.
     */
    Corral,

    /**
     * Test the HerdManager class.
     */
    Herd
}
